# Build Instructions - Unity Runner3D

**Offline Game - No Firebase or server configuration needed!**

## Android Build

1. **Open Unity Build Settings**
   - File → Build Settings
   - Select Android
   - Click "Switch Platform"

2. **Player Settings**
   - Company Name: Your Company
   - Product Name: Runner3D
   - Package Name: com.yourcompany.runner3d (must be unique)
   - Version: 1.0.0
   - Minimum API Level: Android 7.0 (API Level 24)
   - Target API Level: Android 13 (API Level 33) or latest

3. **Graphics API**
   - Player Settings → Other Settings
   - Graphics APIs: Vulkan, OpenGLES3
   - Auto Graphics API: Enabled

4. **Build**
   - Build Settings → Build
   - Choose output folder
   - Wait for build to complete
   - Install APK on device via ADB or direct transfer

## iOS Build (macOS only)

1. **Switch to iOS**
   - Build Settings → iOS → Switch Platform

2. **Player Settings**
   - Bundle Identifier: com.yourcompany.runner3d
   - Version: 1.0.0
   - Target minimum iOS Version: 13.0

3. **Xcode Build**
   - Build Settings → Build
   - Open generated Xcode project
   - Sign with Apple Developer account
   - Build and run on device

## Testing

### On Device
- Enable Developer Mode
- Enable USB Debugging (Android)
- Connect device via USB
- File → Build and Run

### Unity Remote
- Install Unity Remote 5 on device
- Edit → Project Settings → Editor
- Select device in Unity Remote

## Troubleshooting

### Build errors
- Clear Library folder and reimport
- Update Unity to latest LTS version
- Verify all SDK versions are compatible

### Performance
- Profile on actual device, not editor
- Reduce quality settings for low-end devices
- Use object pooling (already implemented)
- Optimize textures and models

### Data Loss
- PlayerPrefs data is stored in app storage
- Uninstalling the app will clear saved data
- Clearing app data will reset scores and settings

## Optimization Tips

1. **Texture Compression**
   - Android: ETC2
   - iOS: ASTC

2. **Audio Compression**
   - Background music: Vorbis
   - SFX: ADPCM

3. **Graphics Quality Levels**
   - Low: Simple shaders, reduced particles
   - Medium: Balanced
   - High: Full effects

4. **Target 60 FPS** on mid-range devices
