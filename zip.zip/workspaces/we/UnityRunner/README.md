# 3D Runner - Unity Mobile Game

Complete Unity C# project for Android/iOS endless runner game.
**100% Offline - No server required!**

## Setup Instructions

1. **Install Unity Hub** (https://unity.com/download)
2. **Install Unity 2022.3 LTS** or newer with:
   - Android Build Support
   - iOS Build Support (macOS only)
   - Visual Studio or VS Code

3. **Create New Unity Project**:
   - Template: 3D (URP - Universal Render Pipeline)
   - Project Name: Runner3D

4. **Import Files**:
   - Copy all scripts from `Scripts/` to `Assets/Scripts/`

5. **Setup Scene**:
   - Create empty GameObject "GameManager" → attach `GameManager.cs`
   - Create empty "Player" → attach `PlayerController.cs`
   - Create "Main Camera" → attach `CameraFollow.cs`
   - Create Canvas → attach `UIManager.cs`
   - Create empty "SpawnManager" → attach `ObstacleSpawner.cs`

6. **Build**:
   - File → Build Settings
   - Switch to Android/iOS
   - Player Settings → set package name, icons
   - Build and Run

## Features

- ✅ **Fully Offline** - No login/registration required
- ✅ **Auto Local Save** - Each device automatically creates unique ID
- 10 playable characters (Runner, Chicken, Roblox, Horse, Ninja, Astronaut, Knight, Alien, Penguin, Slime)
- 3-lane endless runner
- Jump mechanics
- Dynamic obstacles (zombies)
- Day/night cycle
- Multi-language support (EN, TR, ES)
- Local score system (PlayerPrefs)
- Settings menu
- Audio system

## Data Storage

All game data is stored locally using Unity's PlayerPrefs:
- `DeviceId` - Auto-generated unique identifier
- `BestScore` - Personal best score
- `TotalGames` - Number of games played
- `Language` - Selected language
- `MusicVolume` - Audio settings
- `GraphicsQuality` - Graphics settings

## Controls

- Swipe Left/Right: Change lane
- Swipe Up / Tap: Jump
- Pause button in-game
