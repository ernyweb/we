using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    [Header("Main Menu")]
    public GameObject mainMenuPanel;
    public TMP_Text welcomeText;
    public Button playButton;
    public Button settingsButton;
    public GameObject characterSelectorPanel;
    public Button[] characterButtons;

    [Header("Game UI")]
    public GameObject gameUIPanel;
    public TMP_Text scoreText;
    public TMP_Text bestScoreText;
    public Image speedometerNeedle;
    public TMP_Text speedValueText;
    public Slider distanceSlider;
    public TMP_Text distanceText;

    [Header("Pause Menu")]
    public GameObject pausePanel;
    public Button resumeButton;
    public Button restartButton;
    public Button mainMenuButton;

    [Header("Game Over")]
    public GameObject gameOverPanel;
    public TMP_Text finalScoreText;
    public TMP_Text newBestText;
    public Button retryButton;

    [Header("Settings")]
    public GameObject settingsPanel;
    public Slider volumeSlider;
    public Dropdown qualityDropdown;
    public Dropdown languageDropdown;

    void Start()
    {
        SetupButtons();
        ShowMainMenu();
    }

    void SetupButtons()
    {
        playButton?.onClick.AddListener(() => {
            GameManager.Instance?.StartGame();
        });

        settingsButton?.onClick.AddListener(() => {
            settingsPanel?.SetActive(true);
        });

        resumeButton?.onClick.AddListener(() => {
            GameManager.Instance?.PauseGame();
        });

        restartButton?.onClick.AddListener(() => {
            GameManager.Instance?.RestartGame();
        });

        mainMenuButton?.onClick.AddListener(() => {
            GameManager.Instance?.ShowMainMenu();
        });

        retryButton?.onClick.AddListener(() => {
            GameManager.Instance?.RestartGame();
        });

        // Volume slider
        volumeSlider?.onValueChanged.AddListener((value) => {
            AudioListener.volume = value;
            PlayerPrefs.SetFloat("MusicVolume", value);
        });

        // Quality dropdown
        qualityDropdown?.onValueChanged.AddListener((value) => {
            QualitySettings.SetQualityLevel(value);
            PlayerPrefs.SetInt("GraphicsQuality", value);
        });

        // Character selection
        for (int i = 0; i < characterButtons.Length; i++)
        {
            int index = i;
            characterButtons[i]?.onClick.AddListener(() => {
                SelectCharacter(index);
            });
        }
    }

    public void ShowMainMenu()
    {
        mainMenuPanel?.SetActive(true);
        gameUIPanel?.SetActive(false);
        pausePanel?.SetActive(false);
        gameOverPanel?.SetActive(false);

        welcomeText.text = "Runner3D Mobile";
        UpdateBestScore(GameManager.Instance?.bestScore ?? 0);
    }

    public void ShowGameUI()
    {
        mainMenuPanel?.SetActive(false);
        gameUIPanel?.SetActive(true);
        pausePanel?.SetActive(false);
        gameOverPanel?.SetActive(false);
    }

    public void ShowPauseMenu(bool show)
    {
        pausePanel?.SetActive(show);
    }

    public void ShowGameOver(int score, int best)
    {
        gameOverPanel?.SetActive(true);
        finalScoreText.text = $"Score: {score}";
        newBestText.gameObject.SetActive(score >= best);
    }

    public void UpdateScore(int score)
    {
        scoreText.text = $"Score: {score}";
    }

    public void UpdateBestScore(int best)
    {
        bestScoreText.text = $"Best: {best}";
    }

    public void UpdateSpeedometer(float speed)
    {
        // Rotate needle from -120 to +120 degrees
        float t = Mathf.InverseLerp(6f, 36f, speed);
        float angle = Mathf.Lerp(-120f, 120f, t);
        speedometerNeedle.transform.rotation = Quaternion.Euler(0, 0, -angle);

        speedValueText.text = $"{Mathf.FloorToInt(speed * 10)} km/h";
    }

    public void UpdateDistanceProgress(float current, float goal)
    {
        distanceSlider.value = current / goal;
        distanceText.text = $"{Mathf.FloorToInt(current)} / {Mathf.FloorToInt(goal)} m";
    }

    void SelectCharacter(int index)
    {
        if (index < 0 || index >= System.Enum.GetValues(typeof(CharacterType)).Length) return;

        CharacterType character = (CharacterType)index;
        GameManager.Instance?.player?.ChangeCharacter(character);

        // Update UI to show selected character
        for (int i = 0; i < characterButtons.Length; i++)
        {
            Image img = characterButtons[i].GetComponent<Image>();
            if (img != null)
            {
                img.color = (i == index) ? Color.yellow : Color.white;
            }
        }
    }
}
