using UnityEngine;
using System.Collections.Generic;

public class LocalizationManager : MonoBehaviour
{
    public static LocalizationManager Instance { get; private set; }

    private Dictionary<string, Dictionary<string, string>> translations = new Dictionary<string, Dictionary<string, string>>();
    private string currentLanguage = "en";

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }

        InitializeTranslations();
        LoadLanguage();
    }

    void InitializeTranslations()
    {
        // English
        translations["en"] = new Dictionary<string, string>
        {
            { "play", "Play" },
            { "settings", "Settings" },
            { "pause", "Pause" },
            { "resume", "Resume" },
            { "restart", "Restart" },
            { "main_menu", "Main Menu" },
            { "game_over", "Game Over" },
            { "score", "Score:" },
            { "best", "Best:" },
            { "new_best", "New Best Score!" },
            { "controls", "Swipe left/right to change lanes\nSwipe up or tap to jump" }
        };

        // Turkish
        translations["tr"] = new Dictionary<string, string>
        {
            { "play", "Oyna" },
            { "settings", "Ayarlar" },
            { "pause", "Duraklat" },
            { "resume", "Devam" },
            { "restart", "Yeniden Başlat" },
            { "main_menu", "Ana Menü" },
            { "game_over", "Oyun Bitti" },
            { "score", "Skor:" },
            { "best", "En İyi:" },
            { "new_best", "Yeni Rekor!" },
            { "controls", "Şerit değiştirmek için sağa/sola kaydır\nZıplamak için yukarı kaydır veya dokun" }
        };

        // Spanish
        translations["es"] = new Dictionary<string, string>
        {
            { "play", "Jugar" },
            { "settings", "Ajustes" },
            { "pause", "Pausa" },
            { "resume", "Reanudar" },
            { "restart", "Reiniciar" },
            { "main_menu", "Menú Principal" },
            { "game_over", "Juego Terminado" },
            { "score", "Puntuación:" },
            { "best", "Mejor:" },
            { "new_best", "¡Nuevo Récord!" },
            { "controls", "Desliza izquierda/derecha para cambiar de carril\nDesliza arriba o toca para saltar" }
        };
    }

    public string GetText(string key, Dictionary<string, string> variables = null)
    {
        if (!translations.ContainsKey(currentLanguage) || !translations[currentLanguage].ContainsKey(key))
        {
            return key;
        }

        string text = translations[currentLanguage][key];

        if (variables != null)
        {
            foreach (var variable in variables)
            {
                text = text.Replace("{" + variable.Key + "}", variable.Value);
            }
        }

        return text;
    }

    public void SetLanguage(string languageCode)
    {
        if (translations.ContainsKey(languageCode))
        {
            currentLanguage = languageCode;
            PlayerPrefs.SetString("Language", currentLanguage);
            PlayerPrefs.Save();
        }
    }

    void LoadLanguage()
    {
        currentLanguage = PlayerPrefs.GetString("Language", "en");
    }
}
