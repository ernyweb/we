using UnityEngine;
using System.Collections.Generic;

public class AudioManager : MonoBehaviour
{
    public static AudioManager Instance { get; private set; }

    [Header("Audio Sources")]
    public AudioSource musicSource;
    public AudioSource sfxSource;

    [Header("Music Clips")]
    public AudioClip lobbyMusic;
    public AudioClip gameMusic;

    [Header("SFX Clips")]
    public AudioClip jumpSFX;
    public AudioClip hitSFX;
    public AudioClip collectSFX;

    private Dictionary<string, AudioClip> sfxDictionary = new Dictionary<string, AudioClip>();

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        // Initialize SFX dictionary
        sfxDictionary["Jump"] = jumpSFX;
        sfxDictionary["Hit"] = hitSFX;
        sfxDictionary["Collect"] = collectSFX;

        // Load volume from settings
        float volume = PlayerPrefs.GetFloat("MusicVolume", 0.6f);
        musicSource.volume = volume;
        sfxSource.volume = volume;
    }

    public void PlayMusic()
    {
        if (musicSource == null || gameMusic == null) return;

        musicSource.clip = gameMusic;
        musicSource.loop = true;
        musicSource.Play();
    }

    public void PlayLobbyMusic()
    {
        if (musicSource == null || lobbyMusic == null) return;

        musicSource.clip = lobbyMusic;
        musicSource.loop = true;
        musicSource.Play();
    }

    public void StopMusic()
    {
        musicSource?.Stop();
    }

    public void PauseMusic()
    {
        musicSource?.Pause();
    }

    public void ResumeMusic()
    {
        musicSource?.UnPause();
    }

    public void PlaySFX(string sfxName)
    {
        if (sfxSource == null || !sfxDictionary.ContainsKey(sfxName)) return;

        AudioClip clip = sfxDictionary[sfxName];
        if (clip != null)
        {
            sfxSource.PlayOneShot(clip);
        }
    }

    public void SetVolume(float volume)
    {
        musicSource.volume = volume;
        sfxSource.volume = volume;
    }
}
