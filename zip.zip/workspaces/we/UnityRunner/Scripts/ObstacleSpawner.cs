using UnityEngine;
using System.Collections.Generic;

public class ObstacleSpawner : MonoBehaviour
{
    [Header("Spawn Settings")]
    public GameObject[] obstaclePrefabs;
    public float spawnDistance = -80f;
    public float spawnInterval = 2f;
    public float minSpawnInterval = 0.8f;
    private float spawnTimer = 0f;

    [Header("Obstacle Pool")]
    private List<GameObject> activeObstacles = new List<GameObject>();
    public int poolSize = 20;
    private Queue<GameObject> obstaclePool = new Queue<GameObject>();

    [Header("Lane Settings")]
    private float[] lanes = { -2.4f, 0f, 2.4f };

    [Header("Environment")]
    public GameObject groundPrefab;
    public GameObject housePrefab;
    private List<GameObject> groundSegments = new List<GameObject>();
    private List<GameObject> houses = new List<GameObject>();

    void Start()
    {
        InitializePool();
        SpawnInitialGround();
        SpawnInitialHouses();
    }

    void Update()
    {
        if (!GameManager.Instance.isPlaying || GameManager.Instance.isPaused) return;

        spawnTimer += Time.deltaTime;

        // Gradually decrease spawn interval as speed increases
        float currentInterval = Mathf.Lerp(spawnInterval, minSpawnInterval,
            GameManager.Instance.gameSpeed / GameManager.Instance.maxSpeed);

        if (spawnTimer >= currentInterval)
        {
            SpawnObstacle();
            spawnTimer = 0f;
        }

        UpdateObstacles();
        UpdateGround();
        UpdateHouses();
    }

    void InitializePool()
    {
        if (obstaclePrefabs.Length == 0) return;

        for (int i = 0; i < poolSize; i++)
        {
            GameObject prefab = obstaclePrefabs[Random.Range(0, obstaclePrefabs.Length)];
            GameObject obj = Instantiate(prefab);
            obj.SetActive(false);
            obstaclePool.Enqueue(obj);
        }
    }

    void SpawnObstacle()
    {
        if (obstaclePool.Count == 0) return;

        GameObject obstacle = obstaclePool.Dequeue();
        obstacle.SetActive(true);

        // Random lane
        int laneIndex = Random.Range(0, 3);
        float xPos = lanes[laneIndex];

        // Randomize height (tall vs short)
        Obstacle obstacleScript = obstacle.GetComponent<Obstacle>();
        if (obstacleScript != null)
        {
            obstacleScript.isTall = Random.value < 0.28f;
            float height = obstacleScript.isTall ? Random.Range(1.9f, 2.9f) : Random.Range(1.2f, 2.6f);
            obstacle.transform.localScale = new Vector3(1f, height, 1f);
        }

        obstacle.transform.position = new Vector3(xPos, 0f, spawnDistance);
        activeObstacles.Add(obstacle);
    }

    void UpdateObstacles()
    {
        float speed = GameManager.Instance.gameSpeed;

        for (int i = activeObstacles.Count - 1; i >= 0; i--)
        {
            GameObject obstacle = activeObstacles[i];
            if (obstacle == null) continue;

            obstacle.transform.position += Vector3.forward * speed * Time.deltaTime;

            // Recycle if passed player
            if (obstacle.transform.position.z > 10f)
            {
                obstacle.SetActive(false);
                obstaclePool.Enqueue(obstacle);
                activeObstacles.RemoveAt(i);
            }
        }
    }

    void SpawnInitialGround()
    {
        if (groundPrefab == null) return;

        for (int i = 0; i < 10; i++)
        {
            GameObject ground = Instantiate(groundPrefab);
            ground.transform.position = new Vector3(0, -0.01f, i * -100f);
            groundSegments.Add(ground);
        }
    }

    void UpdateGround()
    {
        if (groundSegments.Count == 0) return;

        float speed = GameManager.Instance.gameSpeed;

        foreach (GameObject ground in groundSegments)
        {
            ground.transform.position += Vector3.forward * speed * Time.deltaTime;

            if (ground.transform.position.z > 50f)
            {
                // Move to back
                ground.transform.position = new Vector3(0, -0.01f, ground.transform.position.z - 1000f);
            }
        }
    }

    void SpawnInitialHouses()
    {
        if (housePrefab == null) return;

        for (int side = -1; side <= 1; side += 2)
        {
            for (int z = -10; z > -800; z -= Random.Range(18, 30))
            {
                SpawnHouse(side, z);
            }
        }
    }

    void SpawnHouse(int side, float z)
    {
        if (housePrefab == null) return;

        GameObject house = Instantiate(housePrefab);
        float x = side * (8.5f + Random.Range(-1f, 1f));
        house.transform.position = new Vector3(x, 0f, z + Random.Range(-3f, 3f));

        // Random color
        Renderer renderer = house.GetComponentInChildren<Renderer>();
        if (renderer != null)
        {
            Color[] colors = {
                new Color(1f, 0.42f, 0.42f),
                new Color(1f, 0.82f, 0.4f),
                new Color(0.42f, 0.91f, 0.69f),
                new Color(0.56f, 0.78f, 1f)
            };
            renderer.material.color = colors[Random.Range(0, colors.Length)];
        }

        houses.Add(house);
    }

    void UpdateHouses()
    {
        float speed = GameManager.Instance.gameSpeed;

        for (int i = houses.Count - 1; i >= 0; i--)
        {
            GameObject house = houses[i];
            if (house == null) continue;

            house.transform.position += Vector3.forward * speed * Time.deltaTime;

            if (house.transform.position.z > 6f)
            {
                int side = house.transform.position.x > 0 ? 1 : -1;
                house.transform.position = new Vector3(
                    side * (8.5f + Random.Range(-1f, 1f)),
                    0f,
                    Random.Range(-700f, -780f)
                );
            }
        }
    }

    public void StartSpawning()
    {
        spawnTimer = 0f;
    }

    public void StopSpawning()
    {
        // Deactivate all obstacles
        foreach (GameObject obstacle in activeObstacles)
        {
            if (obstacle != null)
            {
                obstacle.SetActive(false);
                obstaclePool.Enqueue(obstacle);
            }
        }
        activeObstacles.Clear();
    }
}
