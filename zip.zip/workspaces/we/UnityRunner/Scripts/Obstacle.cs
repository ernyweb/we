using UnityEngine;

public class Obstacle : MonoBehaviour
{
    public bool isTall = false;
    public int health = 1;

    public void TakeDamage(int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Destroy(gameObject);
        }
    }
}
