using UnityEngine;

public class PlayerController : MonoBehaviour
{
    [Header("Movement")]
    public float laneDistance = 2.4f;
    public float laneChangeSpeed = 15f;
    private int currentLane = 1; // 0 = left, 1 = middle, 2 = right
    private Vector3 targetPosition;

    [Header("Jump")]
    public float jumpSpeed = 8.5f;
    public float gravity = -30f;
    public float groundY = 0.7f;
    private float verticalVelocity = 0f;
    private bool isGrounded = true;
    private bool isJumping = false;

    [Header("Character Model")]
    public GameObject characterModel;
    private Animator animator;
    private CharacterType currentCharacter = CharacterType.Runner;

    [Header("Input")]
    private Vector2 touchStartPos;
    private bool isSwiping = false;
    private const float swipeThreshold = 50f;

    void Start()
    {
        targetPosition = transform.position;
        if (characterModel != null)
        {
            animator = characterModel.GetComponent<Animator>();
        }
        LoadSelectedCharacter();
    }

    void Update()
    {
        if (!GameManager.Instance.isPlaying || GameManager.Instance.isPaused) return;

        HandleInput();
        UpdateMovement();
        UpdateAnimation();
    }

    void HandleInput()
    {
        // Keyboard input (for testing)
        if (Input.GetKeyDown(KeyCode.LeftArrow) && currentLane > 0)
        {
            ChangeLane(-1);
        }
        else if (Input.GetKeyDown(KeyCode.RightArrow) && currentLane < 2)
        {
            ChangeLane(1);
        }

        if ((Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.UpArrow)) && isGrounded)
        {
            Jump();
        }

        // Touch input (mobile)
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Began)
            {
                touchStartPos = touch.position;
                isSwiping = true;
            }
            else if (touch.phase == TouchPhase.Ended && isSwiping)
            {
                Vector2 swipeDelta = touch.position - touchStartPos;
                isSwiping = false;

                if (swipeDelta.magnitude > swipeThreshold)
                {
                    if (Mathf.Abs(swipeDelta.x) > Mathf.Abs(swipeDelta.y))
                    {
                        // Horizontal swipe
                        if (swipeDelta.x > 0 && currentLane < 2)
                            ChangeLane(1);
                        else if (swipeDelta.x < 0 && currentLane > 0)
                            ChangeLane(-1);
                    }
                    else if (swipeDelta.y > 0 && isGrounded)
                    {
                        // Upward swipe = jump
                        Jump();
                    }
                }
                else if (isGrounded)
                {
                    // Tap = jump
                    Jump();
                }
            }
        }
    }

    void ChangeLane(int direction)
    {
        currentLane = Mathf.Clamp(currentLane + direction, 0, 2);
        float targetX = (currentLane - 1) * laneDistance;
        targetPosition = new Vector3(targetX, transform.position.y, transform.position.z);
    }

    void Jump()
    {
        if (!isGrounded) return;
        verticalVelocity = jumpSpeed;
        isGrounded = false;
        isJumping = true;
        AudioManager.Instance?.PlaySFX("Jump");
    }

    void UpdateMovement()
    {
        // Horizontal movement (lane switching)
        float currentX = transform.position.x;
        float newX = Mathf.Lerp(currentX, targetPosition.x, laneChangeSpeed * Time.deltaTime);

        // Vertical movement (jump/gravity)
        verticalVelocity += gravity * Time.deltaTime;
        float newY = transform.position.y + verticalVelocity * Time.deltaTime;

        // Ground check
        if (newY <= groundY)
        {
            newY = groundY;
            verticalVelocity = 0f;
            isGrounded = true;
            isJumping = false;
        }

        transform.position = new Vector3(newX, newY, transform.position.z);
    }

    void UpdateAnimation()
    {
        if (animator == null) return;

        animator.SetBool("IsRunning", GameManager.Instance.isPlaying);
        animator.SetBool("IsJumping", isJumping);
        animator.SetFloat("Speed", GameManager.Instance.gameSpeed / GameManager.Instance.maxSpeed);
    }

    public void ResetPlayer()
    {
        currentLane = 1;
        targetPosition = new Vector3(0, groundY, 3.2f);
        transform.position = targetPosition;
        verticalVelocity = 0f;
        isGrounded = true;
        isJumping = false;
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Obstacle"))
        {
            // Check if player is jumping high enough to clear short obstacles
            Obstacle obstacle = other.GetComponent<Obstacle>();
            if (obstacle != null && !obstacle.isTall && transform.position.y > groundY + 0.6f)
            {
                // Cleared the obstacle
                return;
            }

            // Hit obstacle
            AudioManager.Instance?.PlaySFX("Hit");
            GameManager.Instance?.GameOver();
        }
        else if (other.CompareTag("Collectible"))
        {
            AudioManager.Instance?.PlaySFX("Collect");
            Destroy(other.gameObject);
        }
    }

    public void ChangeCharacter(CharacterType newChar)
    {
        currentCharacter = newChar;
        PlayerPrefs.SetInt("SelectedCharacter", (int)currentCharacter);
        PlayerPrefs.Save();
        // Instantiate new character model
        LoadCharacterModel();
    }

    void LoadSelectedCharacter()
    {
        currentCharacter = (CharacterType)PlayerPrefs.GetInt("SelectedCharacter", 0);
        LoadCharacterModel();
    }

    void LoadCharacterModel()
    {
        // Destroy old model
        if (characterModel != null)
        {
            Destroy(characterModel);
        }

        // Load new model from Resources
        string modelPath = "Characters/" + currentCharacter.ToString();
        GameObject prefab = Resources.Load<GameObject>(modelPath);
        if (prefab != null)
        {
            characterModel = Instantiate(prefab, transform);
            animator = characterModel.GetComponent<Animator>();
        }
    }
}

public enum CharacterType
{
    Runner,
    Chicken,
    Roblox,
    Horse,
    Ninja,
    Astronaut,
    Knight,
    Alien,
    Penguin,
    Slime
}
