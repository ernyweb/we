using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [Header("Target")]
    public Transform target;

    [Header("Offset")]
    public Vector3 offset = new Vector3(0, 4.5f, 9f);

    [Header("Smoothing")]
    public float smoothSpeed = 5f;
    public bool lookAtTarget = true;

    void LateUpdate()
    {
        if (target == null) return;

        // Calculate desired position
        Vector3 desiredPosition = target.position + offset;

        // Smoothly interpolate
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed * Time.deltaTime);
        transform.position = smoothedPosition;

        // Look at target
        if (lookAtTarget)
        {
            Vector3 lookPos = target.position;
            lookPos.y += 1.2f;
            transform.LookAt(lookPos);
        }
    }
}
