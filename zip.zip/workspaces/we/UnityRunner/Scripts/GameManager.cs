using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }

    [Header("Game State")]
    public bool isPlaying = false;
    public bool isPaused = false;
    public float gameSpeed = 8f;
    public float speedIncrement = 0.5f;
    public float maxSpeed = 36f;
    public int score = 0;
    public int bestScore = 0;

    [Header("References")]
    public PlayerController player;
    public ObstacleSpawner spawner;
    public UIManager uiManager;
    public AudioManager audioManager;

    [Header("Day/Night Cycle")]
    public Light sunLight;
    public Light moonLight;
    public float dayLength = 140f;
    private float dayTimer = 0f;

    [Header("Distance Tracking")]
    public float distanceRun = 0f;
    public float distanceGoal = 1500f;
    private const float DIST_MIN = 1200f;
    private const float DIST_MAX = 2200f;

    [Header("Local Save Data")]
    public string deviceId = null;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        InitializeDeviceId();
        LoadBestScore();
        LoadSettings();
        ShowMainMenu();
    }

    void Update()
    {
        if (!isPlaying || isPaused) return;

        // Increase speed over time
        gameSpeed = Mathf.Min(gameSpeed + speedIncrement * Time.deltaTime * 0.1f, maxSpeed);

        // Update score based on distance
        float distThisFrame = gameSpeed * Time.deltaTime * 10f;
        distanceRun += distThisFrame;
        score = Mathf.FloorToInt(distanceRun);

        // Update day/night cycle
        UpdateDayNight();

        // Update UI
        uiManager?.UpdateScore(score);
        uiManager?.UpdateSpeedometer(gameSpeed);
        uiManager?.UpdateDistanceProgress(distanceRun, distanceGoal);
    }

    public void StartGame()
    {
        isPlaying = true;
        isPaused = false;
        score = 0;
        distanceRun = 0f;
        gameSpeed = 8f;
        dayTimer = 0f;
        distanceGoal = Random.Range(DIST_MIN, DIST_MAX);

        player?.ResetPlayer();
        spawner?.StartSpawning();
        uiManager?.ShowGameUI();
        audioManager?.PlayMusic();
    }

    public void PauseGame()
    {
        isPaused = !isPaused;
        Time.timeScale = isPaused ? 0f : 1f;
        uiManager?.ShowPauseMenu(isPaused);
        if (isPaused)
            audioManager?.PauseMusic();
        else
            audioManager?.ResumeMusic();
    }

    public void GameOver()
    {
        isPlaying = false;
        spawner?.StopSpawning();
        audioManager?.StopMusic();

        if (score > bestScore)
        {
            bestScore = score;
            SaveBestScore();
        }

        uiManager?.ShowGameOver(score, bestScore);
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void ShowMainMenu()
    {
        isPlaying = false;
        isPaused = false;
        Time.timeScale = 1f;
        uiManager?.ShowMainMenu();
        audioManager?.PlayLobbyMusic();
    }

    void UpdateDayNight()
    {
        dayTimer += Time.deltaTime * 0.6f;
        float phase = (dayTimer % dayLength) / dayLength;
        float angle = phase * Mathf.PI * 2f;

        float lightStrength = Mathf.Clamp(0.25f + Mathf.Sin(angle) * 0.55f, 0.12f, 1.0f);
        float moonStrength = 0.18f + Mathf.Max(0, -Mathf.Sin(angle)) * 0.35f;

        if (sunLight != null)
        {
            sunLight.intensity = lightStrength;
            sunLight.color = Color.Lerp(new Color(1f, 0.8f, 0.6f), Color.white, lightStrength);
        }

        if (moonLight != null)
        {
            moonLight.intensity = moonStrength;
        }
    }

    void InitializeDeviceId()
    {
        // Auto-create local device ID if doesn't exist
        deviceId = PlayerPrefs.GetString("DeviceId", "");
        if (string.IsNullOrEmpty(deviceId))
        {
            deviceId = System.Guid.NewGuid().ToString();
            PlayerPrefs.SetString("DeviceId", deviceId);
            PlayerPrefs.Save();
            Debug.Log($"New device ID created: {deviceId}");
        }
        else
        {
            Debug.Log($"Device ID loaded: {deviceId}");
        }
    }

    void LoadBestScore()
    {
        bestScore = PlayerPrefs.GetInt("BestScore", 0);
    }

    void SaveBestScore()
    {
        PlayerPrefs.SetInt("BestScore", bestScore);
        PlayerPrefs.SetInt("TotalGames", PlayerPrefs.GetInt("TotalGames", 0) + 1);
        PlayerPrefs.Save();
    }

    void LoadSettings()
    {
        // Load user settings from PlayerPrefs
        QualitySettings.SetQualityLevel(PlayerPrefs.GetInt("GraphicsQuality", 2));
        AudioListener.volume = PlayerPrefs.GetFloat("MusicVolume", 0.6f);
    }

    public void SaveSettings(int quality, float volume)
    {
        PlayerPrefs.SetInt("GraphicsQuality", quality);
        PlayerPrefs.SetFloat("MusicVolume", volume);
        PlayerPrefs.Save();

        QualitySettings.SetQualityLevel(quality);
        AudioListener.volume = volume;
    }
}


